/*----------------------------------------------------------------------------
LAB EXERCISE - Weather Station Appcessory
 ----------------------------------------
	In this exercise we will create a BLE weather station appcessory that will measure several environmental parameters and
	send them to our smartphone.
 *----------------------------------------------------------------------------*/

#include "mbed.h"
#include "x_cube_mems.h"
#include "BLEDevice.h"
#include "EnvironmentalSensingService.h" //Complete the Environmental Sensing Services
#include "EnvironmentalSensingService2.h"
#include "DeviceInformationService.h"
#include "Utils.h"/* To turn on/off the debug messages on the console edit this file; NEED_CONSOLE_OUTPUT 1/0( it will have an impact on code-size and power consumption.) */
#define PI 3.1415169f
BLEDevice  ble;
DigitalOut led(LED1);
Ticker update;
Ticker aliveness;

volatile float TEMPERATURE_C = 20;
volatile float HUMIDITY = 50;
volatile float PRESSURE = 1000;
volatile float WIND_DIRECTION = 0;
int16_t MagRaw[3];
volatile AxesRaw_TypeDef MAG_Value;

EnvironmentalSensingService *env_sensing_serv;
EnvironmentalSensingService2 *env_sensing_serv2;

const static char     DEVICE_NAME[]        = "SUJITHA"; 
static const uint16_t uuid16_list[]        = {GattService::UUID_ENVIRONMENTAL_SENSING_SERVICE};

static volatile bool  triggerSensorPolling = false;

void disconnectionCallback(Gap::Handle_t handle, Gap::DisconnectionReason_t reason)
{
    DEBUG("Disconnected!\n\r");
    DEBUG("Restarting the advertising process\n\r");
    ble.startAdvertising(); // restart advertising
}

void connectionCallback(Gap::Handle_t handle, const Gap::ConnectionParams_t *reason)
{    DEBUG("Connected\r\n");}

void update_handler(void)
{    triggerSensorPolling = true;}

void aliveness_handler (void)
{	led = !led;	}

	

int main(void)
{
	int32_t axes[3];
	  /* Create a sensor shield object */
    static X_CUBE_MEMS *Sensors = X_CUBE_MEMS::Instance();

    update.attach(update_handler, 2);
	  aliveness.attach(aliveness_handler,0.5);

    DEBUG("Initialising \n\r");
    ble.init();
    ble.onDisconnection(disconnectionCallback);
    ble.onConnection(connectionCallback);

	  /* Setup primary services. */

		env_sensing_serv = new EnvironmentalSensingService(ble,HUMIDITY ,TEMPERATURE_C);
		env_sensing_serv2 = new EnvironmentalSensingService2(ble,WIND_DIRECTION ,PRESSURE);

    /* Setup auxiliary services. */

    /* Setup advertising. */
		ble.accumulateAdvertisingPayload(GapAdvertisingData::BREDR_NOT_SUPPORTED | GapAdvertisingData::LE_GENERAL_DISCOVERABLE);
		ble.accumulateAdvertisingPayload(GapAdvertisingData::COMPLETE_LOCAL_NAME, (uint8_t *)DEVICE_NAME, sizeof(DEVICE_NAME));
    ble.accumulateAdvertisingPayload(GapAdvertisingData::MY_WEATHER_STATION);
    ble.setAdvertisingType(GapAdvertisingParams::ADV_CONNECTABLE_UNDIRECTED);
		ble.accumulateAdvertisingPayload(GapAdvertisingData::COMPLETE_LIST_16BIT_SERVICE_IDS, (uint8_t *)uuid16_list, sizeof(uuid16_list));
    ble.setAdvertisingInterval(1600); 
    ble.startAdvertising();

    while (true)
    {
        if (triggerSensorPolling & ble.getGapState().connected)
        {
				 /* Read the environmental sensors and the magnetometer */
						Sensors->lis3mdl.GetAxes((AxesRaw_TypeDef *) &MAG_Value);
						Sensors->hts221.GetHumidity((float *)&HUMIDITY);
						Sensors->lps25h.GetPressure((float *)&PRESSURE);
						Sensors->hts221.GetTemperature((float *)&TEMPERATURE_C);
															
					
				 /* Calcule the direction where the system is pointing  relative to North with the magnetometer measurments.*/
						if (MAG_Value.AXIS_X < 140) WIND_DIRECTION = 0; 
									else if (MAG_Value.AXIS_X >= 360) WIND_DIRECTION = 180; 
									else if (MAG_Value.AXIS_X >= 280 && -MAG_Value.AXIS_Y < 250&& MAG_Value.AXIS_X < 360  ) WIND_DIRECTION = 225; 
									else if (MAG_Value.AXIS_X >= 280 && -MAG_Value.AXIS_Y > 250&& MAG_Value.AXIS_X < 360  ) WIND_DIRECTION = 135; 
                   else if (MAG_Value.AXIS_X >= 140 && -MAG_Value.AXIS_Y > 250 && MAG_Value.AXIS_X < 200 ) WIND_DIRECTION = 45; 
										else if (MAG_Value.AXIS_X >= 200 && -MAG_Value.AXIS_Y > 250&& MAG_Value.AXIS_X < 280  ) WIND_DIRECTION = 90;
										else if (MAG_Value.AXIS_X >= 200 && -MAG_Value.AXIS_Y < 250&& MAG_Value.AXIS_X < 280  ) WIND_DIRECTION = 270; 
											else if (MAG_Value.AXIS_X >= 140 && -MAG_Value.AXIS_Y < 250 && MAG_Value.AXIS_X < 200  ) WIND_DIRECTION = 315; 
                      
       
					/* Multiply by 10^Number of decimals that needs to be pass to the client acordingly to the standards */
							PRESSURE = (uint32_t)(PRESSURE *1000);
							HUMIDITY =(uint16_t)(HUMIDITY *100);
							TEMPERATURE_C = (uint16_t)(TEMPERATURE_C *100);
							WIND_DIRECTION =(uint16_t)(WIND_DIRECTION *100);
					/* Update the characteristics */ 
						env_sensing_serv->updateHumidity(HUMIDITY);
						env_sensing_serv->updateTemperature(TEMPERATURE_C);
						env_sensing_serv2->updateWinddirection(WIND_DIRECTION);
						env_sensing_serv2->updatePressure(PRESSURE);
						triggerSensorPolling = false;
        }
        else
        {
            ble.waitForEvent();
        }
    }
}

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************//

