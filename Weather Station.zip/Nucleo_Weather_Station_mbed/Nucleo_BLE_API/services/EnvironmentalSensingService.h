/* ARM University Program Microcontroller Library
 * 
 * Environmental Sensing Service
 *
 * This software is distributed under an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

#ifndef __BLE_ENVIRONMENTAL_SENSING_SERVICE_H__
#define __BLE_ENVIRONMENTAL_SENSING_SERVICE_H__

#include "BLEDevice.h"

class EnvironmentalSensingService {

public:
    /**
     * Constructor.
     *
     * param[in] _ble
     *               Reference to the underlying BLEDevice.
     * param[in] humidity percentage (16-bit unsigned, 2 decimals).
     *               initial value for the humidity value.
     * param[in] temperature in degrees Celsius (16-bit signed, 2 decimals).
     *               initial value for the temperature
     */



EnvironmentalSensingService(BLEDevice &_ble, uint16_t humidity, int16_t temperature) :
		ble(_ble),
//Read and notify service for temperature characteristic
		temperaturechar(GattCharacteristic::UUID_TEMPERATURE_CHAR, 
(uint8_t  *)&temperature, sizeof(int16_t), sizeof(int16_t),
			 GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_READ |GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_NOTIFY),
//Read and notify service for humidity characteristic
		humiditychar(GattCharacteristic::UUID_HUMIDITY_CHAR, 
(uint8_t *)&humidity, sizeof(uint16_t), sizeof(uint16_t),
		 GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_READ |GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_NOTIFY)
		
  {
   static bool serviceAdded = false; /* We should only ever need to add the information service once. */
   if (serviceAdded) {
   return;
   }
GattCharacteristic *charTable[] = { &temperaturechar, &humiditychar  };
GattService environmentalService(GattService::UUID_ENVIRONMENTAL_SENSING_SERVICE, charTable, sizeof(charTable) / sizeof(GattCharacteristic *));
 
  ble.addService(environmentalService);
   serviceAdded = true;
   }

	  /* Set a new 16-bit value for the humidity measurement.  */
	 void updateHumidity(uint16_t humidity) {
						   
        ble.updateCharacteristicValue(humiditychar.getValueAttribute().getHandle(),(uint8_t*)&humidity,sizeof(uint16_t));
    }
	 
		 /* Set a new 16-bit value for the temperature measurement.  */
		void updateTemperature(int16_t temperature) {
							
        ble.updateCharacteristicValue(temperaturechar.getValueAttribute().getHandle(), (uint8_t*)&temperature,sizeof(uint16_t));
    }

private:
    BLEDevice            		&ble;
    GattCharacteristic   		humiditychar;
    GattCharacteristic   		temperaturechar;
	
};

#endif /* #ifndef __BLE_ENVIRONMENTAL_SENSING_SERVICE_H__*/


// *******************************ARM University Program Copyright � ARM Ltd 2015*************************************//