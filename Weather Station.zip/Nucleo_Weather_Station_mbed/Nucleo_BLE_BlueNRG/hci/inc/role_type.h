#ifndef _ROLE_TYPE_H_
#define _ROLE_TYPE_H_

typedef enum {
  CLIENT,
  SERVER
} BLE_RoleTypeDef;

#endif /* _ROLE_TYPE_H_ */